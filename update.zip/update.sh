#!/bin/sh

# First argument of script will be update directory location of upadte files
update_dir=$1
cortex_firmware_home="/cortex"


/etc/init.d/cortex_nxne disable
rm /etc/init.d/cortex_nxne
/etc/init.d/cortex_thio disable
cp $update_dir/cortex_thio /etc/init.d/cortex_thio
chmod +x /etc/init.d/cortex_thio
/etc/init.d/cortex_thio enable
/etc/init.d/cortex_thio restart
rm -rf /cortex/nextion
rm /cortex/thingstream/Makefile*
rm /cortex/thingstream/*.c
rm /cortex/thingstream/*.h


########## Start update #############
echo "Updating from directory: $update_dir"

# Go to cortex firmware codebase
cd $cortex_firmware_home

if [ $? -eq 0 ]; then
   echo Navigating into cortex home directory
else
   echo Cortex firmware home directory do not exist
   exit 1
fi

# Apply patch file
patch_file="$update_dir/update.patch"
patch -p1 < $patch_file

if [ $? -eq 0 ]; then
   echo Patch applied successfully
else
   echo Patch applying failed
   exit 1
fi


cp /cortex/uci/display /etc/config/display
cp /cortex/uci/eastron_sdm630mct /etc/config/eastron_sdm630mct
cp /cortex/uci/registry_RPE /etc/config/registry_RPE
cp /cortex/uci/sma_stp15000tl30 /etc/configsma_stp15000tl30
